public class EnergyProduct extends Plant{
	
	public EnergyProduct(GamePanel parent, int x, int y) {
		super(parent, x, y);
		setHealth(200);
	}
	public void stop(){
    }
}
