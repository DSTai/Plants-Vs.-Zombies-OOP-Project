public class GreenPea extends Pea{
	public GreenPea(GamePanel parent, int lane, int startX) {
		super(parent, lane, startX);
		damage=300;
	}
}
