
public class Plant extends Character {
	
    public GamePanel gp;
    
    public Plant(GamePanel parent,int x,int y){
        this.x = x;
        this.y = y;
        gp = parent;     
    }
    public void remove(){   	
    }
	public void stop() {	
	}
}
