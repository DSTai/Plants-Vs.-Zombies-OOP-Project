
public class PlantButton extends Button{
	enum PlantType{
        None,
        Sunflower,
        Peashooter,
        FreezePeashooter,
        WallNut,
        GatlingPeashooter
    }
	
}
