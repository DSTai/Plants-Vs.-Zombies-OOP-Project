
public class Zomboni extends Zombie{
	
	public Zomboni(GamePanel parent, int lane) {
		super(parent, lane);
		setAttack(500);
        setHealth(2500);
        setSpeed(1);
	}

}
