
public class WallNut extends Defender {

	public WallNut(GamePanel parent, int x, int y) {
		super(parent, x, y);
		ExtraHealth(1800);
	}
}
