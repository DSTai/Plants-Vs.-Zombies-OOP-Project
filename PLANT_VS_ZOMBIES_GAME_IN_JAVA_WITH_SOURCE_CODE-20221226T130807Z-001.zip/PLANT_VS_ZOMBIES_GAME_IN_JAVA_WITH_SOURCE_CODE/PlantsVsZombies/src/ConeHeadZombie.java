
public class ConeHeadZombie extends Zombie {

    public ConeHeadZombie(GamePanel parent,int lane){
        super(parent,lane);
        setAttack(20);
        setHealth(2000);
        setSpeed(1);
    }
}
