public class GatlingPea extends Pea{
    public GatlingPea(GamePanel parent,int lane,int startX){
    	super(parent,lane,startX);
    	damage = 250;
    }
}
