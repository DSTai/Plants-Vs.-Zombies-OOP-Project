
public class ShovelButton extends Button{
	enum ShovelType{
		None,
		Remove
	}
}
