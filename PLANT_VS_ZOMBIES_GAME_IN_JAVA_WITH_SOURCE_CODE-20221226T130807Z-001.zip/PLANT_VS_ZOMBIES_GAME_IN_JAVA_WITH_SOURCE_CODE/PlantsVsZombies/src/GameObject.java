
public interface GameObject {
	int getX();
}
