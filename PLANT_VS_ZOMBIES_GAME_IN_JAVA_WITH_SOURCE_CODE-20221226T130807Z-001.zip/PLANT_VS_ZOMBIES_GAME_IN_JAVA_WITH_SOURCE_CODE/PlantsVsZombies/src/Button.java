import javax.swing.JButton;

public class Button extends JButton implements GameObject{
}

